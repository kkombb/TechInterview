//
//  AlbumInfoViewController.swift
//  TechInterviewProject
//
//  Created by KirtisOrendorff on 10/21/18.
//  Copyright © 2018 KirtisOrendorff. All rights reserved.
//

import UIKit

class AlbumInfoViewController: UIViewController {

    
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var recordCompanyLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var artistLabel: UILabel!
    @IBOutlet weak var albumLabel: UILabel!
    
    //functioning variables
    var dateFormatter = DateFormatter()
    var album = FetchedData.JsonData(feed: nil)
    var row:Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Album Info"
        
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .medium
        
        print(album)
        print(row)
        
        artistLabel.text = album.feed?.results[row!].artistName
        albumLabel.text = album.feed?.results[row!].name

    }
    
}
